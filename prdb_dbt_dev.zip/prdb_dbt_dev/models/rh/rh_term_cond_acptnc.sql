/*
  rh_term_cond_acptnc
*/

{{ 
    config(
        materialized='incremental',
        unique_key='term_cond_acptnc_id'
    ) 
}}

with source_data as (
select 
      a.id as term_cond_acptnc_id,
	  a.terms_and_conditions__c as term_cond_id,
	  a.name as term_cond_acptnc_nm,
	  a.user__c as usr_id,
	  TO_TIMESTAMP_TZ(regexp_replace (a.accepted_date__c ,'T',' ')) as acpt_ts,
	  a.createdbyid as src_sys_cre_by_id,
	  CONCAT(c.FirstName, ' ', c.LastName) as src_sys_cre_by_nm,
	  TO_TIMESTAMP_TZ(regexp_replace ( a.createddate ,'T',' ')) as src_sys_cre_ts,
	  case when lower(a.isdeleted)='true' then 1 when lower(a.isdeleted)='false' then 0 end as row_not_recv_ind,
	  a.lastmodifiedbyid as src_sys_updt_by_id,
	  CONCAT(m.FirstName, ' ', m.LastName) as src_sys_updt_by_nm,
	  TO_TIMESTAMP_TZ(regexp_replace ( a.lastmodifieddate ,'T',' ')) as src_sys_updt_ts,
	  TO_TIMESTAMP_TZ(regexp_replace ( a.lastreferenceddate ,'T',' ')) as src_sys_ref_ts,
	  TO_TIMESTAMP_TZ(regexp_replace ( a.lastvieweddate ,'T',' ')) as src_sys_view_ts,
	  TO_TIMESTAMP_TZ(regexp_replace ( a.systemmodstamp ,'T',' ')) as src_sys_mod_ts
	  from prdb.PRDB_AZURE_TEST.terms_and_conditions_acceptance__c a
	  left join prdb.PRDB_AZURE_TEST.user c on (c.id=a.CreatedById) 
	  left join prdb.PRDB_AZURE_TEST.user m on (m.id=a.LastModifiedById)
)
select *
from source_data
{% if is_incremental() %}
  where src_sys_updt_ts > (select max(src_sys_updt_ts) from {{ this }})
{% endif %}

