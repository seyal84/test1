{{ 
    config(
        materialized='incremental',
        unique_key='prtcpnt_deleg_id'
    ) 
}}
with source_data as (
select 
	 contact__c as deleg_party_id,
	 createdbyid src_sys_cre_by_id ,
	 TO_TIMESTAMP(createddate) as src_sys_cre_ts,
	 id as prtcpnt_deleg_id,
	 case when lower( isdeleted)='true' then 1 when lower(isdeleted)='false' then 0 end as row_not_recv_ind,
	 lastmodifiedbyid as src_sys_updt_by_id,
	 TO_TIMESTAMP(lastmodifieddate) as src_sys_updt_ts,
     TO_TIMESTAMP(lastreferenceddate) as src_sys_ref_ts,
     TO_TIMESTAMP(lastvieweddate) as src_sys_view_ts,
	 name as prtcpnt_deleg_nbr ,
	 participant__c as prtcpnt_id ,
	 status__c as prtcpnt_deleg_stat_nm ,
	 TO_TIMESTAMP(systemmodstamp) as src_sys_mod_ts,
	 case when lower(primary_delegate__c)='true' then 1 when lower(primary_delegate__c)='false' then 0 end as prtcpnt_pri_deleg_ind,
	 case when lower(Attestation__c)='true' then 1 when lower(Attestation__c)='false' then 0 end as attestation_ind,
	 Attestation_TimeStamp__c as attestation_ts,
	 Attested_by__c as attestation_by_id,
	 case when lower(Is_Created_by_Bulk_Import__c)='true' then 1 when lower(Is_Created_by_Bulk_Import__c)='false' then 0 end as bulk_imp_cre_ind
	 from prdb.PRDB_AZURE_TEST.Patient_Delegate__c

)
select *
from source_data
{% if is_incremental() %}
  where src_sys_updt_ts > (select max(src_sys_updt_ts) from {{ this }})
{% endif %}
